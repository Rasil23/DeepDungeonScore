using System;
using System.Collections.Generic;
using System.Linq;
using Dalamud.Game;
using Dalamud.Game.ClientState;
using Dalamud.Game.ClientState.Actors.Types;
using Dalamud.Game.ClientState.Party;
using Dalamud.Game.Gui;
using Dalamud.IoC;
using Dalamud.Interface;
using Dalamud.Plugin;
using ImGuiNET;
using System.Numerics;

namespace DeepDungeonScore
{
    /// <summary>
    /// Main plugin class for Deep Dungeon Score.  This plugin tracks trap‑induced
    /// debuffs and player deaths inside Deep Dungeons (Palace of the Dead and
    /// Heaven‑on‑High) and awards points to the player responsible.  Points
    /// accumulate across floors and dungeon runs as long as the party remains
    /// unchanged.  A small ImGui overlay displays each party member's total.
    /// </summary>
    public sealed class DeepDungeonScorePlugin : IDalamudPlugin
    {
        public string Name => "DeepDungeonScore";

        private readonly DalamudPluginInterface _pluginInterface;
        private readonly ClientState _clientState;
        private readonly PartyList _partyList;
        private readonly Framework _framework;
        private readonly ChatGui _chatGui;

        // Tracks whether we are in a Deep Dungeon instance.
        private bool _inDeepDungeon;

        // Map of party member (content ID) to their current score.
        private readonly Dictionary<ulong, int> _scoreByContentId = new();

        // Last known list of party member content IDs.  Used to detect party
        // composition changes.
        private List<ulong> _trackedPartyContentIds = new();

        // Last known set of status effect IDs per party member.  Used to
        // determine when new debuffs appear.
        private readonly Dictionary<ulong, HashSet<uint>> _lastStatuses = new();

        // Tracks whether a party member was dead on the previous update.
        private readonly Dictionary<ulong, bool> _wasDead = new();

        // List of debuff names that correspond to Deep Dungeon traps or mishaps.
        private readonly HashSet<string> _trackedDebuffNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "Silence",
            "Pacification",
            "Damage Down",
            "Vulnerability Up",
            "Toad",
            "Otter",
            "Accursed Pox",
            "Weakness" // Weakness occurs on resurrection after death; exclude separately if needed.
        };

        // IDs of ContentFinderCondition entries for Palace of the Dead floors.  These
        // IDs were sourced from the ACT Deep Dungeon plugin data file【811539375307433†L334-L349】.
        private readonly HashSet<uint> _potdContentIds = new()
        {
            // Floors 1–10 through 191–200 (IDs 174–218)
            174, 175, 176, 177, 178, 204, 205, 206, 207,
            208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218
        };

        // IDs of ContentFinderCondition entries for Heaven‑on‑High floors.  These
        // correspond to floors 1–100 (IDs 540–549)【811539375307433†L334-L349】.
        private readonly HashSet<uint> _hohContentIds = new()
        {
            540, 541, 542, 543, 544, 545, 546, 547, 548, 549
        };

        public DeepDungeonScorePlugin(
            [RequiredVersion("1.0")] DalamudPluginInterface pluginInterface,
            ClientState clientState,
            PartyList partyList,
            Framework framework,
            ChatGui chatGui)
        {
            _pluginInterface = pluginInterface;
            _clientState = clientState;
            _partyList = partyList;
            _framework = framework;
            _chatGui = chatGui;

            // Subscribe to relevant events.
            _pluginInterface.UiBuilder.Draw += DrawUi;
            _framework.Update += OnFrameworkUpdate;
            _clientState.TerritoryChanged += OnTerritoryChanged;

            // Perform initial party setup if we are already in Deep Dungeon when
            // the plugin is loaded.  Otherwise, tracking will begin when
            // TerritoryChanged fires.
            CheckDeepDungeonStatus();
        }

        public void Dispose()
        {
            // Unsubscribe from events and clean up any lingering state【287671248092447†L85-L91】.
            _pluginInterface.UiBuilder.Draw -= DrawUi;
            _framework.Update -= OnFrameworkUpdate;
            _clientState.TerritoryChanged -= OnTerritoryChanged;
        }

        /// <summary>
        /// Called when the player enters a new territory.  Used to start or
        /// stop score tracking based on whether the new area is a deep dungeon.
        /// </summary>
        private void OnTerritoryChanged(object? sender, ushort newTerritory)
        {
            CheckDeepDungeonStatus();
        }

        /// <summary>
        /// Determine whether the current duty/territory qualifies as a Deep
        /// Dungeon.  If the player has just entered a Deep Dungeon, begin
        /// tracking; if they have left, pause tracking but do not reset
        /// scores immediately.
        /// </summary>
        private void CheckDeepDungeonStatus()
        {
            bool wasInDeepDungeon = _inDeepDungeon;
            _inDeepDungeon = IsInDeepDungeon();

            if (_inDeepDungeon && !wasInDeepDungeon)
            {
                // Entering a deep dungeon.  Initialize or continue tracking
                // depending on whether the party matches the previously
                // recorded party composition.  If the party differs, reset
                // scores.
                InitializePartyState();
            }
        }

        /// <summary>
        /// Returns true if the current duty is a Deep Dungeon (PotD or HoH).
        /// Uses ContentFinderCondition IDs rather than territory because these
        /// values are more consistent across floors.  The IDs used here are
        /// documented in the ACT Deep Dungeon plugin’s dataset【811539375307433†L334-L349】.
        /// </summary>
        private bool IsInDeepDungeon()
        {
            // ClientState has a CurrentContentFinderConditionId property which
            // returns 0 when not in a duty.  When in duty, it returns the
            // ContentFinderCondition ID of the current instance.  We assume
            // this property exists on API level 14; if not, fallback to
            // using TerritoryType (which identifies the zone).  Since the
            // plugin may run on multiple API revisions, we use reflection
            // to obtain the property dynamically.
            try
            {
                var cfcIdProp = _clientState.GetType().GetProperty("CurrentContentFinderConditionId");
                if (cfcIdProp != null)
                {
                    var value = cfcIdProp.GetValue(_clientState);
                    if (value is uint cfcId)
                    {
                        return _potdContentIds.Contains(cfcId) || _hohContentIds.Contains(cfcId);
                    }
                }
            }
            catch
            {
                // Fall through to territory check below if reflection fails.
            }

            // Fallback: check TerritoryType.  For Palace of the Dead floors
            // 1–50 the territory types are 561–565【798594948580247†L1789-L1833】.  The
            // territory IDs for Heaven‑on‑High floors are not well documented,
            // so this fallback may not cover HoH correctly.  To support HoH
            // floors when territory IDs are known, add them to this set.
            var deepDungeonTerritories = new HashSet<ushort>
            {
                561, // PotD Floors 1–10【798594948580247†L1789-L1833】
                562, // PotD Floors 11–20【798594948580247†L1789-L1833】
                563, // PotD Floors 21–30【798594948580247†L1789-L1833】
                564, // PotD Floors 31–40【798594948580247†L1789-L1833】
                565  // PotD Floors 41–50【798594948580247†L1789-L1833】
                // TODO: add Heaven-on-High territory IDs here once known.
            };
            return deepDungeonTerritories.Contains(_clientState.TerritoryType);
        }

        /// <summary>
        /// Initialize or update tracking state for the current party.  If the
        /// party composition has changed since the last time we tracked, reset
        /// score and state.
        /// </summary>
        private void InitializePartyState()
        {
            var currentPartyIds = GetCurrentPartyContentIds();
            bool sameParty = _trackedPartyContentIds.SequenceEqual(currentPartyIds);

            if (!sameParty)
            {
                // New party composition; reset scores and state.
                _scoreByContentId.Clear();
                _lastStatuses.Clear();
                _wasDead.Clear();
                _trackedPartyContentIds = currentPartyIds;
                foreach (var id in currentPartyIds)
                {
                    _scoreByContentId[id] = 0;
                    _lastStatuses[id] = new HashSet<uint>();
                    _wasDead[id] = false;
                }
            }
            else
            {
                // Same party; ensure dictionaries contain all current members.
                foreach (var id in currentPartyIds)
                {
                    if (!_scoreByContentId.ContainsKey(id))
                        _scoreByContentId[id] = 0;
                    if (!_lastStatuses.ContainsKey(id))
                        _lastStatuses[id] = new HashSet<uint>();
                    if (!_wasDead.ContainsKey(id))
                        _wasDead[id] = false;
                }
            }
        }

        /// <summary>
        /// Returns a list of content IDs for the current party members.  If not
        /// in a duty or party, returns an empty list.
        /// </summary>
        private List<ulong> GetCurrentPartyContentIds()
        {
            var ids = new List<ulong>();
            foreach (var member in _partyList)
            {
                if (member?.ObjectId > 0)
                {
                    // Prefer the ContentId if available; fallback to ObjectId.
                    ulong cid = 0;
                    try
                    {
                        var cidProp = member.GetType().GetProperty("ContentId");
                        if (cidProp != null)
                        {
                            object? value = cidProp.GetValue(member);
                            if (value is ulong contentId && contentId != 0)
                            {
                                cid = contentId;
                            }
                        }
                    }
                    catch
                    {
                        // Reflection failed; ignore.
                    }
                    if (cid == 0)
                    {
                        cid = member.ObjectId;
                    }
                    ids.Add(cid);
                }
            }
            return ids;
        }

        /// <summary>
        /// Per‑frame update callback.  When tracking is active, this checks for
        /// new debuffs and deaths on party members and updates scores
        /// accordingly.
        /// </summary>
        private void OnFrameworkUpdate(Framework framework)
        {
            if (!_inDeepDungeon)
                return;

            // Ensure party state is initialized; this also handles resets if
            // composition changed mid‑dungeon.
            InitializePartyState();

            // Collect new debuffs grouped by their target players.  We will
            // later aggregate these to attribute points to the triggering player.
            var newDebuffEvents = new List<(uint StatusId, string StatusName, List<ulong> Targets)>();

            foreach (var member in _partyList)
            {
                if (member?.ObjectId == 0)
                    continue;

                ulong contentId = GetMemberContentId(member);
                if (contentId == 0)
                    continue;

                // Get or create the set of last statuses for this player.
                if (!_lastStatuses.TryGetValue(contentId, out var lastSet))
                {
                    lastSet = new HashSet<uint>();
                    _lastStatuses[contentId] = lastSet;
                }

                // Track death state.
                bool isDead = false;
                try
                {
                    // PartyMember has a IsDead property on API 14.
                    var isDeadProp = member.GetType().GetProperty("IsDead");
                    if (isDeadProp != null)
                    {
                        object? value = isDeadProp.GetValue(member);
                        if (value is bool b)
                            isDead = b;
                    }
                    else
                    {
                        // Fallback: check CurrentHp.
                        if (member.CurrentHP == 0)
                            isDead = true;
                    }
                }
                catch
                {
                    // ignore reflection errors
                }

                if (_wasDead.TryGetValue(contentId, out bool wasDeadFlag))
                {
                    if (!wasDeadFlag && isDead)
                    {
                        // Newly dead.  Award 3 points to the dead player.
                        _scoreByContentId[contentId] += 3;
                    }
                    // Update death state.
                    _wasDead[contentId] = isDead;
                }
                else
                {
                    _wasDead[contentId] = isDead;
                }

                // Inspect statuses for new debuffs.
                foreach (var status in member.Statuses)
                {
                    // Skip statuses without a status ID.
                    uint sid = status.StatusId;
                    if (sid == 0)
                        continue;

                    if (!lastSet.Contains(sid))
                    {
                        // New status.  Get the name via status.Name; fallback to
                        // unknown if not available.
                        string sname = status.Status?.Name ?? string.Empty;
                        if (string.IsNullOrEmpty(sname))
                        {
                            // Some API revisions provide name on StatusEffect?
                            try
                            {
                                var nameProp = status.GetType().GetProperty("Name");
                                if (nameProp != null)
                                {
                                    object? nv = nameProp.GetValue(status);
                                    sname = nv?.ToString() ?? string.Empty;
                                }
                            }
                            catch
                            {
                                // ignore
                            }
                        }

                        if (_trackedDebuffNames.Contains(sname))
                        {
                            // Record this debuff event.  We'll group later.
                            var existing = newDebuffEvents.Find(e => e.StatusId == sid);
                            if (existing.StatusId != 0)
                            {
                                existing.Targets.Add(contentId);
                                // update the tuple in the list
                                int index = newDebuffEvents.IndexOf(existing);
                                newDebuffEvents[index] = existing;
                            }
                            else
                            {
                                newDebuffEvents.Add((sid, sname, new List<ulong> { contentId }));
                            }
                        }

                        // Add to lastSet regardless of whether we tracked it.
                        lastSet.Add(sid);
                    }
                }

                // Remove statuses that have expired from lastSet.
                lastSet.RemoveWhere(id => !member.Statuses.Any(s => s.StatusId == id));
            }

            // Now attribute points for each debuff event.
            foreach (var (statusId, statusName, targets) in newDebuffEvents)
            {
                if (targets.Count == 0)
                    continue;

                // Determine the triggering player.  Heuristic: if the debuff
                // hit multiple players simultaneously, assume the first target
                // (sorted by party order) triggered it.  If it hit only one
                // player, that player is the trigger.  This is a simplified
                // approach because the game does not expose trap activator
                // information.  For improved accuracy, chat log parsing can
                // be added.
                ulong triggerCid;
                if (targets.Count == 1)
                {
                    triggerCid = targets[0];
                }
                else
                {
                    // Sort by party list order.  The PartyList enumerator is
                    // already ordered, so we find the first target in that list.
                    triggerCid = _partyList
                        .Select(m => GetMemberContentId(m))
                        .FirstOrDefault(cid => targets.Contains(cid));
                    if (triggerCid == 0)
                    {
                        // Fallback: just take the first from the list.
                        triggerCid = targets[0];
                    }
                }

                // Award one point per affected player.
                int points = targets.Count;
                if (_scoreByContentId.ContainsKey(triggerCid))
                {
                    _scoreByContentId[triggerCid] += points;
                }
            }
        }

        /// <summary>
        /// Helper to extract the unique content ID (if available) for a party
        /// member.  Falls back to object ID when content ID is missing.
        /// </summary>
        private ulong GetMemberContentId(PartyMember? member)
        {
            if (member == null || member.ObjectId == 0)
                return 0;
            try
            {
                var cidProp = member.GetType().GetProperty("ContentId");
                if (cidProp != null)
                {
                    object? val = cidProp.GetValue(member);
                    if (val is ulong cid && cid != 0)
                        return cid;
                }
            }
            catch
            {
                // ignore
            }
            return member.ObjectId;
        }

        /// <summary>
        /// Draws the ImGui overlay window containing the scoreboard.  Only
        /// displays when the plugin is tracking scores (i.e. inside a Deep
        /// Dungeon and the party has been initialized).
        /// </summary>
        private void DrawUi()
        {
            if (!_inDeepDungeon || _scoreByContentId.Count == 0)
                return;

            ImGui.SetNextWindowSize(new Vector2(250, 150), ImGuiCond.FirstUseEver);
            var flags = ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoTitleBar |
                        ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoScrollbar |
                        ImGuiWindowFlags.NoFocusOnAppearing;
            if (ImGui.Begin("Deep Dungeon Scoreboard", flags))
            {
                ImGui.Text("Deep Dungeon Scoreboard");
                ImGui.Separator();

                // Sort scores descending.
                foreach (var entry in _scoreByContentId.OrderByDescending(kv => kv.Value))
                {
                    ulong cid = entry.Key;
                    int score = entry.Value;
                    string name = GetMemberNameByContentId(cid);
                    ImGui.TextUnformatted($"{name}: {score}");
                }
                ImGui.End();
            }
        }

        /// <summary>
        /// Resolve a party member's display name by their content ID.  If the
        /// player is not currently in the party, returns the content ID
        /// itself.
        /// </summary>
        private string GetMemberNameByContentId(ulong cid)
        {
            foreach (var member in _partyList)
            {
                if (member?.ObjectId == 0)
                    continue;
                ulong mid = GetMemberContentId(member);
                if (mid == cid)
                {
                    // Format as "Name (World)" to differentiate same names.
                    var worldName = member.World.GameData?.Name ?? string.Empty;
                    return string.IsNullOrEmpty(worldName)
                        ? member.Name.ToString()
                        : $"{member.Name} ({worldName})";
                }
            }
            // Fallback: show the numeric ID.
            return cid.ToString();
        }
    }
}